import Register from 'views/auth/register';

// ==============================|| PAGE ||============================== //

export default function RegisterPage() {
  return <Register />;
}
