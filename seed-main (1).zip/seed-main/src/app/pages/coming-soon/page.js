import ComingSoon from 'views/maintenance/coming-soon';

// ==============================|| PAGE ||============================== //

export default function ComingSoonPage() {
  return <ComingSoon />;
}
