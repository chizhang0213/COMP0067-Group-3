import HomePage from 'views/home-page';

// ==============================|| PAGE ||============================== //

export default function HomeViewPage() {
  return <HomePage />;
}
