// project import
import HomePage from './home';
// import samplePage from './home';
import project from './projects';
import modules from './modules';

// ==============================|| MENU ITEMS ||============================== //

const menuItems = {
  // items: [samplePage, pages, other]
  items: [HomePage, modules, project]
};

export default menuItems;
